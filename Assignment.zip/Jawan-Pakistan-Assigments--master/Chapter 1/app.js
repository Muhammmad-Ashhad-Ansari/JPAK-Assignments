// ALERT#1
alert("hello user");

// ALERT#2
alert("Error! Please enter a valid password.");

// ALERT#3
alert("Welcome To Lala Land....\nHappy Coding!");

// ALERT#4
alert("Welcome to JS Land...");
alert("Happy Coding!\n Prevent this Page From Creating Additoanal dialogs.");

// ALERT#5
alert("Hello... i can run JS through my web browser's console");

