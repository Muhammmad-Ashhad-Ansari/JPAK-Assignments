// VARIABLES FOR NUMBERS # 1
var age=17;
alert("I am "+age+" years old");

// VARIABLES FOR NUMBERS # 2
var n=14;
alert("You have visited this site "+n+" times");

// // VARIABLES FOR NUMBERS # 3
// var birthYear=2006;
// document.write("My birth year is "+birthYear);
// document.write("Data type of my decleared variable is ", typeof birthYear);

// VARIABLES FOR NUMBERS # 4
var Name="Jhon Doe ", Product="T-shirts", Quantity="5 ";
document.write(Name+"odered "+Quantity+Product+"on Arkham Clothing store");