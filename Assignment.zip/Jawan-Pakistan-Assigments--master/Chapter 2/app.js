// VARIABLES FOR STRINGS # 1
var userName, myName;

// VARIABLES FOR STRINGS # 2
var myName;
myName="Hashir Ansari";

// VARIABLES FOR STRINGS # 3
var message;
message="Hello World";
alert(message);

// VARIABLES FOR STRINGS # 4
var Uname="Hashir Ansari", age="17 years old", education="Intermediate";
alert(Uname);
alert(age);
alert(education);

// VARIABLES FOR STRINGS # 5
var food="PIZZA";
alert(food);

food="PIZZ";
alert(food);

food="PIZ";
alert(food);

food="PI";
alert(food);

food="P";
alert(food);

// VARIABLES FOR STRINGS # 6
var email="hashirsalam300@gmail.com";
alert("My email address is "+email);

// VARIABLES FOR STRINGS # 7
var book;
book="A smarter way to learn JavaScript";
alert("I am trying to Learn From a Book"+ book);

// VARIABLES FOR STRINGS # 8
document.write("Yah! i can write HTML content through JavaScript");

// VARIABLES FOR STRINGS # 9
alert("▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬");
